# Installation
> `npm install --save @types/babylon`

# Summary
This package contains type definitions for babylon ( https://github.com/babel/babylon ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/babylon

Additional Details
 * Last updated: Wed, 13 Feb 2019 16:16:46 GMT
 * Dependencies: @types/babel-types
 * Global values: none

# Credits
These definitions were written by Troy Gerwien <https://github.com/yortus>, Marvin Hagemeister <https://github.com/marvinhagemeister>.
